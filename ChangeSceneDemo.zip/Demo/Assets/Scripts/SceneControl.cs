﻿using UnityEngine;
using System.Collections;

public class SceneControl : MonoBehaviour
{
	public void LoadBackScene()
	{
		Application.LoadLevel("backbutton");
	}

	public void LoadHighScoreScene()
	{
		Application.LoadLevel("highscore");
	}

	public void LoadMenuScene()
	{
		Application.LoadLevel("main");
	}
}
